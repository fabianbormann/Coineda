Exported from Kraken. This file is not the data.
